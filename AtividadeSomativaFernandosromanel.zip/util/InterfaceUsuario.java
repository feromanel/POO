package util;

import java.util.Scanner;

public class InterfaceUsuario {
    public double pedirValorImovel() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nDigite o valor do imovel: ");
        double valorImovelDigitado =  FormatNumbers.twoDecimalNumbers(scanner.nextDouble());
        if (valorImovelDigitado <=0){
            System.out.print("O valor necessita ser positivo");
        }
        return valorImovelDigitado;
    }

    public int pedirPrazoFinanciamento() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nDigite o prazo do financiamento em anos: ");
        int prazoFinanciamentoDigitado = scanner.nextInt();
        if (prazoFinanciamentoDigitado <=0){
            System.out.print("O valor necessita ser positivo");
        }

        return prazoFinanciamentoDigitado;
    }

    public double pedirTaxaJuros() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nDigite a taxa de juros anual: ");
        double pedirTaxaJuros =  FormatNumbers.twoDecimalNumbers(scanner.nextDouble());
        if (pedirTaxaJuros <=0){
            System.out.print("O valor necessita ser positivo");
        }
        return pedirTaxaJuros;
    }
}
