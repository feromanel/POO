package util;

public final class FormatNumbers {
    public static double twoDecimalNumbers(double number){
        number = Math.round(number * 100);
        number = number/100;
        return number;
    }
}
